# Phishing URL Checker

## Project description
A beginner-friendly cybersecurity project that checks a URL for a few common phishing warning signs using transparent, rule-based scoring.

## Features
- Accepts a URL from the user.
- Checks for selected indicators such as non-HTTPS URLs, unusually long URLs, `@` symbols, several hyphens in a hostname, and suspicious account-related words.
- Prints a simple warning score, assessment, and reasons.
- Does not open or contact the URL.

## Technology
- Python 3
- Jupyter Notebook (optional)
- Python standard library: `urllib.parse`

## Files
- `Mithra_PhishingURLChecker.ipynb` — notebook version.
- `Mithra_PhishingURLChecker.py` — runnable Python script.
- `requirements.txt` — dependencies.
- `Mithra_PhishingURLChecker_ProjectReport.docx` — project documentation.
- `sample_urls.csv` — illustrative sample test cases (not a real-world verified dataset).

## How to run
### Option A: Python script
1. Install Python 3 if it is not already installed.
2. Open a terminal in this folder.
3. Run:
   ```bash
   python Mithra_PhishingURLChecker.py
   ```
4. Enter a URL when prompted.

### Option B: Jupyter Notebook
1. Open the notebook in Jupyter Notebook, JupyterLab, or Google Colab.
2. Run the code cell.
3. Enter a URL when prompted.

## Dataset
This project does not require a downloaded dataset because it uses hand-written rules. `sample_urls.csv` contains illustrative test cases for demonstrating and checking the program only. The example domains use reserved `.example` names and should not be treated as real phishing or legitimate website evidence.

## GitHub upload
1. Sign in to GitHub and create a new **public or private** repository named `phishing-url-checker`.
2. Upload the files in this folder, or use Git:
   ```bash
   git init
   git add .
   git commit -m "Add phishing URL checker project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/phishing-url-checker.git
   git push -u origin main
   ```
3. Replace `YOUR-USERNAME` with your GitHub username. Do not submit the placeholder link; submit the actual repository URL after pushing.

## Important limitation
This project is a learning demonstration, not a reliable security product. A low score does not mean a URL is safe, and a high score does not prove it is malicious. Do not enter passwords, OTPs, or private information into unknown websites.
