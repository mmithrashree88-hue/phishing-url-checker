"""
Project: Phishing URL Checker
Purpose: Educational, rule-based screening of URLs for common phishing warning signs.
Note: This is a basic demonstration, not a security guarantee.
"""

from urllib.parse import urlparse

SUSPICIOUS_WORDS = (
    "login", "verify", "update", "secure", "account", "banking",
    "password", "confirm", "signin", "wallet", "gift"
)

def check_url(url):
    """Return a simple risk score and explanations for a URL."""
    url = url.strip()
    reasons = []
    score = 0

    if not url:
        return {"url": url, "score": 0, "risk": "Invalid input",
                "reasons": ["Please enter a URL."]}

    candidate = url if "://" in url else "http://" + url
    parsed = urlparse(candidate)
    host = (parsed.hostname or "").lower()

    if parsed.scheme != "https":
        score += 1
        reasons.append("Does not use HTTPS")

    if not host or "." not in host:
        score += 2
        reasons.append("Hostname looks incomplete")

    if "@" in url:
        score += 2
        reasons.append("Contains @ symbol, which can disguise the destination")

    if len(url) > 75:
        score += 1
        reasons.append("Unusually long URL")

    if host.count("-") >= 2:
        score += 1
        reasons.append("Hostname contains several hyphens")

    if any(word in url.lower() for word in SUSPICIOUS_WORDS):
        score += 1
        reasons.append("Contains words often seen in urgent account messages")

    if sum(ch.isdigit() for ch in host) >= 5:
        score += 1
        reasons.append("Hostname contains many digits")

    if score >= 4:
        risk = "High warning signs"
    elif score >= 2:
        risk = "Some warning signs"
    else:
        risk = "Few warning signs detected"

    if not reasons:
        reasons.append("No basic warning signs detected by these rules")

    return {"url": url, "score": score, "risk": risk, "reasons": reasons}


def main():
    print("=" * 48)
    print("          PHISHING URL CHECKER")
    print("=" * 48)
    print("Educational tool: do not treat the result as proof.")
    url = input("\nEnter a URL to check: ")
    result = check_url(url)

    print("\nResult")
    print("-" * 48)
    print("URL:", result["url"])
    print("Warning score:", result["score"])
    print("Assessment:", result["risk"])
    print("Reasons:")
    for reason in result["reasons"]:
        print(" -", reason)
    print("\nSafety tip: open important services by typing their")
    print("official address yourself. Never share passwords or OTPs.")


if __name__ == "__main__":
    main()
